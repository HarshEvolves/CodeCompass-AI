def hello():
    print('hello')
