# Core configuration package
